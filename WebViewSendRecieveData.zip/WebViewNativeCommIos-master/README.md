# Web View and Native layer communication in IOS Swift

Shows how to communicate from WebView to Native layer and vice-versa.

Using JavaScript, the same can be achieved conveniently.

Source code for [Article in Medium](https://medium.com/@sreeharikv112/communication-from-webview-to-native-ios-android-app-6d842cefe02d)

Android source can be found in [Github over here](https://github.com/sreeharikv112/WebViewNativeComm)

<br>

<p align="center">  

![resized1](https://user-images.githubusercontent.com/39777674/73593712-06e90200-452d-11ea-89c1-34a3787edd79.gif)

</p>


<br>

